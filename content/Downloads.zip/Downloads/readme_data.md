The flood risk analysis polygon are created from open data source:

Official Community Plan - Land Use achieved from: https://opendata-abbotsford.hub.arcgis.com/

City of Abbotsford Boundary achieved from: https://opendata-abbotsford.hub.arcgis.com/

DEM achieved from https://catalogue.data.gov.bc.ca/dataset/digital-elevation-model-for-british-columbia-cded-1-250-000

Coverpage.jpg achieved from https://www.flickr.com/photos/bcgovphotos/51703450352

before.jpg and after.jpg are achieved and edited from https://www.flickr.com/photos/gsfc/4976450371

UBC logo achieved from https://brand.ubc.ca/guidelines/downloads/

